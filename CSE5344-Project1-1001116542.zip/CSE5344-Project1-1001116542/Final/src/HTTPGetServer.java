
import java.io.*;
import java.net.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class HTTPGetServer extends Thread {

static final String initiate_HTML =
"<html>" +
"<title>HTTP Server</title>" +
"<body>";

static final String terminate_HTML =
"</body>" +
"</html>";

Socket Clnt = null;
BufferedReader inFromClient = null;
DataOutputStream outToClient = null;


public HTTPGetServer(Socket client) {
Clnt = client;
}

public void  run() 
	{
	try {
	    executeRequest();
		} 
	catch (Exception execute_e) 
		{
	    System.out.println(execute_e);
		}
   }


private void executeRequest() throws Exception 
{
	
	PrintWriter fp1;
	
	
	fp1 = new  PrintWriter(new FileWriter("log.txt", true)); 
	
	
	DateFormat TimeDate = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
Calendar calndr = Calendar.getInstance(); 

InputStream Put_Data = Clnt.getInputStream(); // To know the input
	
DataOutputStream get_data = new DataOutputStream(Clnt.getOutputStream());// To know the output
	
	
	BufferedReader buffrd = new BufferedReader(new InputStreamReader(Put_Data));

	
	String Request = buffrd.readLine();
	StringTokenizer token = new StringTokenizer(Request); 	token.nextToken(); 
	String s = token.nextToken();
	int index = s.lastIndexOf('/');
	String filelocation = s.substring(index+1);
	s = filelocation;

	if(filelocation.isEmpty()){
		get_data.writeBytes("Welcome to Home Page");
		fp1.println("::::::::::::::::::::::::::::::::::::");
		System.out.println("Accessing by the client");
		System.out.println(Request);
		fp1.println(Request);
		String ClientInfo = null;
		while ((ClientInfo = buffrd.readLine()).length() != 0) 
		{
			System.out.println(ClientInfo);
		}
		
	}
		
		//Access the File required
	else if(!filelocation.isEmpty()){
		FileInputStream FIS = null ;
		boolean fPresent = true ;
		try 
		{
			FIS = new FileInputStream(s);
		} 
		catch (FileNotFoundException e) 
		{
			fPresent = false ;
		}
		
		fp1.println(":::::::::::::::::::::::::::::::::::::::");
		System.out.println("Access by the Client");
		System.out.println(Request);
		fp1.println(Request);
		String headerLine = null;
	
		while ((headerLine = buffrd.readLine()).length() != 0) 
		{
			System.out.println(headerLine);
		}
	
		// message for the client
		String Code_HTTP = null;
		String Type_Content = null;
		String Body_Content = null;
		
		if (fPresent) 
		{
			Code_HTTP = "HTTP/1.1 200 OK \r\n";
			Type_Content = "Content-Type: " +	Type_Of_Content(s) + "\r\n";
			fp1.println("\r\nHTTP/1.1 200 OK \r\n");
			fp11.println(TimeDate.format(calndr.getTime()));
			fp.println("::::::::::::::::::::::::::::::::");
		} 
		
		else 
		{
			Code_HTTP = "HTTP/1.0 404 Not Found \r\n";
			Type_Content = "Content-Type: text/html \r\n" ;
			fp1.println("HTTP/1.0 404 Not Found \r\n");
			Body_Content = "File Not Found";
			fp1.println(TimeDate.format(calndr.getTime()));
			fp1.println(":::::::::::::::::::::::::::::::");
		}
		
		
		get_data.writeBytes(Code_HTTP);// Code_HTTP Status
		
		
		get_data.writeBytes(Type_Content);// Type of the Content
		
		get_data.writeBytes("\r\n");
		
		//Title
		if (fPresent) 
		{
			get_data.writeBytes(Code_HTTP);
			get_data.writeBytes("\r\n");
			Flow_Value(FIS, get_data);
			FIS.close();
		} 
		else 
		{
			get_data.writeBytes(Code_HTTP);
		}
		
	}
		get_data.close();
		buffrd.close();
		Clnt.close();
		fp1.close();
}

private static void Flow_Value(FileInputStream fis, 
			  OutputStream get_data) throws Exception 
{
		byte[] buf = new byte[1024];
		int bytes = 0;
		while ((bytes = fis.read(buf)) != -1) 
		{
			get_data.write(buf, 0, bytes);
		}
}



private static String Type_Of_Content(String ss) 
{
	if(ss.endsWith(".txt")) 
	{
		return "txt/empty";
	}
	
	return "txt" ;
}


public static void main (String args[]) throws Exception {

ServerSocket Server = new ServerSocket (8000, 20, InetAddress.getByName("127.0.0.1"));
System.out.println ("server waits for the client");

while(true) {
Socket connect = Server.accept();
    (new HTTPGetServer(connect)).start();
}
}
}
