import java.io.*;
import java.net.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

 public class HTTPPostServer extends Thread {

     static final String initiate_HTML =
             "<html>" +
             "<title>HTTP POST Server</title>" + 
             "<body bg-color= red>";
     
     static final String terminate_HTML =
             "</body>" +
             "</html>";
     
     Socket Clnt = null;
     BufferedReader input_from_client = null;
     DataOutputStream output_for_client = null;
     
     public HTTPPostServer(Socket client) {
        Clnt = client;
     }    
     
     public void run() {
 
       String soc = null, limit = null, filename = null, 
Length = null;
       PrintWriter fileoutput = null;
 
       try {
 
    	 //Request will be processed
   	    
         System.out.println( "Client "+
         Clnt.getInetAddress() + ":" +Clnt.getPort() + " got connected");
         
         
        PrintWriter fp2; 
 	fp2 = new PrintWriter(new FileWriter("log1.txt", true)); 
     DateFormat TimeDate = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
 Calendar calndr = Calendar.getInstance(); 
     
         input_from_client = new BufferedReader(new InputStreamReader (Clnt.getInputStream()));          
         output_for_client = new DataOutputStream(Clnt.getOutputStream());
 
         soc = input_from_client.readLine();
         String headerLine = soc;        
         StringTokenizer sfn = new StringTokenizer(headerLine);
         String funcHTTP = sfn.nextToken();
         String Input_Query = sfn.nextToken();
         
         System.out.println(soc);
         
         if (funcHTTP.equals("GET")) {
             System.out.println("Fetch result");
             fp2.write("\r\n###################");
             fp2.write("\r\nFetch result");
             if (Input_Query.equals("/")) {
     
                      String StrgRsp = HTTPPostServer.initiate_HTML +
                      "<form action=\"http://127.0.0.1:8080\" enctype=\"multipart/form-data\"" +
                      "method=\"post\">" +
                      "Enter the name of the File <input name=\"file\" type=\"file\"><br>" +
                     "<input value=\"ClickMe!\" type=\"submit\"></form>" +
                     HTTPPostServer.terminate_HTML;
                    ackRequest(200, StrgRsp , false); 
                   	fp2.write("\r\nHTTP/1.1 200 OK \r\n");
      				fp2.write(TimeDate.format(calndr.getTime()));
      				
                   
                 } else {
                   ackRequest(404, "<b>The Requested resource not found ...." +
                   "Usage: http://127.0.0.1:8080</b>", false);      
                   fp2.write("\r\nHTTP/1.0 404 Not Found  \r\n");
      				fp2.write(TimeDate.format(calndr.getTime()));
      				
                 }
         }
         else { 
             System.out.println("Request Received");
            
                 do {
                     soc = input_from_client.readLine();
                                         
                     if (soc.indexOf("Content-Type: multipart/form-data") != -1) {
                       String boundary = soc.split("boundary=")[1];
                                  
                       while (true) {
                           soc = input_from_client.readLine();
                         
                               if (soc.indexOf("Content-Length:") != -1) {
                               Length = soc.split(" ")[1];
                               System.out.println("Content Length = " + Length);
                               break;
                           }              
                      }
              
                        while (true)
                      {
                           soc = input_from_client.readLine();
                           
                          if (soc.indexOf("--" + boundary) != -1) {
                               filename = input_from_client.readLine().split("filename=")[1].replaceAll("\"", "");                                
                               String [] filelist = filename.split("\\" +                                System.getProperty("file.separator"));
                               filename = filelist[filelist.length - 1];      
                               System.out.println("File to be uploaded = " + filename);
                               break;
                           }              
                       }
                       fp2.write("\r\n :::::::::::::::::::::::::::::");
                       fp2.write("\r\nPOST /"+filename + " HTTP/1.1");
                       String fileContentType = input_from_client.readLine().split(" ")[1];
                       System.out.println("File content type = " + fileContentType);
               
                       input_from_client.readLine(); ";
                       fileoutput = new PrintWriter(filename);
                       String PL = input_from_client.readLine();
                       soc = input_from_client.readLine();     
                       while (true) 
               {
                          
                   if (soc.equals("--" + boundary + "--")) {
                               fileoutput.print(PL);
                               break;
                           }
                           else
                  {
                               fileoutput.println(PL);
                     }
                           PL = crntLn;              
                           crntLn = input_from_client.readLine();
                       }
               
                       ackRequest(200,"File " + filename + "  Uploaded", false);
                       fp2.write("\r\nHTTP/1.1 200 OK \r\n");
          				fp2.write(TimeDate.format(calndr.getTime()));
          				
                       
                       fileoutput.close();           
                     } 
                 }while (input_from_client.ready()); 
                 fp2.close();
               }
           } catch (Exception e) {
                 e.printStackTrace();
           }
         }

         public void ackRequest (int statusCode, String responseString, boolean isFile) throws Exception {
     
             String stat_line = null;
             String serv_details = "Server: Java HTTPServer";
             String CALL = null;
             String FN = null;
             String CTL = "Content-Type: text/html" + "\r\n";
             FileInputStream fin = null;
     
             if (statusCode == 200)
             {
                 stat_line = "HTTP/1.1 200 OK" + "\r\n";
               
             }
             else
                 stat_line = "HTTP/1.0 404 Not Found" + "\r\n";
         
             if (isFile) 
    {
                 FN = responseString;    
                 fin = new FileInputStream(FN);
                 CALL = "Content-Length: " + Integer.toString(fin.available()) + "\r\n";
                 if (!FN.endsWith(".htm") && !FN.endsWith(".html"))
                     CTL = "Content-Type: \r\n";
      }                
             else
     {
                 responseString = HTTPPostServer.initiate_HTML + responseString + HTTPPostServer.terminate_HTML;
                 CALL = "Content-Length: " + responseString.length() + "\r\n";
       }    
             
             output_for_client.writeBytes(stat_line);
             output_for_client.writeBytes(serv_details);
             output_for_client.writeBytes(CTL);
             output_for_client.writeBytes(CALL);
             output_for_client.writeBytes("Connection: close\r\n");
             output_for_client.writeBytes("\r\n");
     
             if (isFile) sendFile(fin, output_for_client);
           
             else
    {
            	 output_for_client.writeBytes(responseString);
     }
             
    output_for_client.close();
        
     }

         public void sendFile (FileInputStream fis, DataOutputStream out) throws Exception {
             byte[] buff = new byte[1024] ;
             int bRead;

             while ((bRead = fin.read(buff)) != -1 ) 
  
             out.write(buff, 0, bRead);
             }
             fis.close();
         }
         
         public static void main (String args[]) throws Exception {
     
             ServerSocket Servsoc = new ServerSocket (8080, 20, InetAddress.getByName("127.0.0.1")); 
             System.out.println ("waiting for the client");
                             
             while(true) {                                 
                     Socket connected = Servsoc.accept();
                     (new HTTPPostServer(connected)).start();
             }
         	
    }
     }

